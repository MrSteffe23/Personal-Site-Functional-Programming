module Model.Event.Category exposing (EventCategory(..), SelectedEventCategories, allSelected, eventCategories, isEventCategorySelected, set, view)

import Html exposing (Html, div, input, text)
import Html.Attributes exposing (checked, class, style, type_)
import Html.Events exposing (onCheck)


type EventCategory
    = Academic
    | Work
    | Project
    | Award


eventCategories =
    [ Academic, Work, Project, Award ]


{-| Type used to represent the state of the selected event categories
-}
type SelectedEventCategories
    = SelectedEventCategories (List EventCategory)


{-| Returns an instance of `SelectedEventCategories` with all categories selected

    isEventCategorySelected Academic allSelected --> True

-}
allSelected : SelectedEventCategories
allSelected =
    SelectedEventCategories eventCategories

{-| Returns an instance of `SelectedEventCategories` with no categories selected

-- isEventCategorySelected Academic noneSelected --> False

-}
noneSelected : SelectedEventCategories
noneSelected =
    SelectedEventCategories []

getListSelected: SelectedEventCategories -> List EventCategory
getListSelected (SelectedEventCategories listEventCategory) =
    listEventCategory

{-| Given a the current state and a `category` it returns whether the `category` is selected.

    isEventCategorySelected Academic allSelected --> True

-}
isEventCategorySelected : EventCategory -> SelectedEventCategories -> Bool
isEventCategorySelected category current =
    (getListSelected current) |> List.any (\x -> x == category)

deleteCategoryFromCurrent: EventCategory -> List EventCategory -> List EventCategory
deleteCategoryFromCurrent =
    let
        auxDeleteCategoryFromCurrent: List EventCategory -> EventCategory -> List EventCategory -> List EventCategory
        auxDeleteCategoryFromCurrent aux category current =
            case current of
                [] -> aux
                x::xs -> if x == category then
                            auxDeleteCategoryFromCurrent aux category xs
                         else
                            auxDeleteCategoryFromCurrent (x::aux) category xs
    in
        auxDeleteCategoryFromCurrent []

{-| Given an `category`, a boolean `value` and the current state, it sets the given `category` in `current` to `value`.

    allSelected |> set Academic False |> isEventCategorySelected Academic --> False

    allSelected |> set Academic False |> isEventCategorySelected Work --> True

-}
set : EventCategory -> Bool -> SelectedEventCategories -> SelectedEventCategories
set category value current =
    if isEventCategorySelected category current == value then
        current
    else
        if value then  -- add category
            SelectedEventCategories (category::(getListSelected current))
        else  -- remove category
            SelectedEventCategories ((getListSelected >> (deleteCategoryFromCurrent category)) current)
            --we will get a reversed list of EventCategory's after deleting one but it doesn't matter


checkbox : String -> Bool -> EventCategory -> Html ( EventCategory, Bool )
checkbox name state category =
    div [ style "display" "inline", class "category-checkbox" ]
        [ input [ type_ "checkbox", onCheck (\c -> ( category, c )), checked state ] []
        , text name
        ]


view : SelectedEventCategories -> Html ( EventCategory, Bool )
view model =
    div []
    [ checkbox "Academic" (model |> isEventCategorySelected Academic) Academic
    , checkbox "Work" (model |> isEventCategorySelected Work) Work
    , checkbox "Project" (model |> isEventCategorySelected Project) Project
    , checkbox "Award" (model |> isEventCategorySelected Award) Award
    ]
