module Model.Repo exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, href, style)
import Json.Decode as De


type alias Repo =
    { name : String
    , description : Maybe String
    , url : String
    , pushedAt : String
    , stars : Int
    }


view : Repo -> Html msg
view repo =
    div [class "repo", style "border" "solid 2px black", style "margin" "1px"]
    [ div [class "repo-name"] [b [] [text "Name: "], text repo.name]
    , div [class "repo-description"] [text "Description: ", text (repo.description |> Maybe.withDefault "None")]
    , div [class "repo-url"] [text "Url: ", a [href repo.url] [ text repo.url]]
    , div [class "repo-stars"] [text "Stars: ", text (String.fromInt repo.stars)]
    , p [style "color" "green" ] [text ("¯\\_(ツ)_/¯")]
    ]

sortByStars : List Repo -> List Repo
sortByStars repos =
    let
        compareFunction: Repo -> Repo -> Order
        compareFunction reposA reposB =
            Basics.compare reposB.stars reposA.stars
    in
    repos |> List.sortWith compareFunction

{-| Deserializes a JSON object to a `Repo`.
Field mapping (JSON -> Elm):

  - name -> name
  - description -> description
  - html\_url -> url
  - pushed\_at -> pushedAt
  - stargazers\_count -> stars

-}
decodeRepo : De.Decoder Repo
decodeRepo =
    De.map5 Repo
        (De.field "name" De.string)
        (De.maybe (De.field "description" De.string))
        (De.field "html_url" De.string)
        (De.field "pushed_at" De.string)
        (De.field "stargazers_count" De.int)