module Model.PersonalDetails exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, id, href, style)


type alias DetailWithName =
    { name : String
    , detail : String
    }


type alias PersonalDetails =
    { name : String
    , contacts : List DetailWithName
    , intro : String
    , socials : List DetailWithName
    }


view : PersonalDetails -> Html msg
view details =
    div [style "border" "5px outset red", style "background-color" "lightblue"]
    [ div [style "text-align" "center"]
      [ h1 [id "name"] [ text details.name]
      , em [id "intro"] [ text details.intro]
      ]
    , h4 [] [ i [] [ text "Contacts:" ]]
    , ul [] (details.contacts |> List.map (\x -> li [] [ text (x.name ++ ": "), a [ class "contact-detail"] [ text x.detail ]]))
    , h4 [] [ i [] [ text "Socials:" ]]
    , ul [] (details.socials |> List.map (\x -> li [] [ text (x.name ++ ": "), a [ href x.detail, class "social-link"] [ text x.detail ]]))
    ]