module Model.Event exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, classList, style, href)
import Model.Event.Category exposing (EventCategory(..))
import Model.Interval as Interval exposing (Interval)


type alias Event =
    { title : String
    , interval : Interval
    , description : Html Never
    , category : EventCategory
    , url : Maybe String
    , tags : List String
    , important : Bool
    }


categoryView : EventCategory -> Html Never
categoryView category =
    case category of
        Academic ->
            text "Academic"

        Work ->
            text "Work"

        Project ->
            text "Project"

        Award ->
            text "Award"


sortByInterval : List Event -> List Event
sortByInterval events =
    let
        compareFunction: Event -> Event -> Order
        compareFunction eventA eventB =
            Interval.compare eventA.interval eventB.interval
    in
    events |> List.sortWith compareFunction

view : Event -> Html Never
view event =
    let
        eventCategoryToString eventCategory = 
            case eventCategory of
                Academic -> "Academic"
                Work -> "Work"
                Project -> "Project"
                Award -> "Award"
        urlview url =
            case url of
                Just validUrl -> a [ href validUrl] [ text validUrl]
                Nothing -> text "No Url"
        getTags =
            event.tags
            |> List.intersperse " "
            |> List.map text
    in
    
    div [classList [("event", True), ("event-important", event.important == True)], style "border" "solid 1px", style "margin" "2px"] 
    [ div [class "event-title"] [b [] [text "Title: "], text event.title]
    , div [class "event-interval"] [text "Interval: ", event.interval |> Interval.view]
    , div [class "event-description"] [text "Description: ", event.description]
    , div [class "event-category"] [text "Category: ", event.category |> eventCategoryToString |> text]
    , div [class "event-url"] [text "Url: ", event.url |> urlview]
    , div [] ((text "Tags: ")::getTags)
    ]